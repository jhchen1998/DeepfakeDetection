from __future__ import print_function,division,absolute_import
import torch
import numpy as np
import random
import torch.nn as nn
import torch.nn.functional as F
import cv2
import matplotlib.pyplot as plt
from torchvision.transforms import Compose, Normalize, ToTensor,Resize

class data_prefetcher():
    def __init__(self,loader):
        self.stream = torch.cuda.Stream() #流加速
        self.loader = iter(loader) #数据迭代器
        self.preload() #数据预加载方法

    def preload(self):
        try:
            self.next_input,self.next_mask,self.next_target = next(self.loader)
        except StopIteration:
            self.next_input = None
            self.next_mask = None
            self.next_target = None
            return
        with torch.cuda.stream(self.stream):
            self.next_input = self.next_input.cuda(non_blocking=True).float()
            self.next_mask = self.next_mask.cuda(non_blocking=True).float()
            self.next_target = self.next_target.cuda(non_blocking=True).long()

    def next(self):
        torch.cuda.current_stream().wait_stream(self.stream)
        input = self.next_input
        mask = self.next_mask
        target = self.next_target
        self.preload()
        return input,mask,target

class data_prefetcher_2():
    def __init__(self,loader):
        self.stream = torch.cuda.Stream() #流加速
        self.loader = iter(loader) #数据迭代器
        self.preload() #数据预加载方法

    def preload(self):
        try:
            self.next_input,self.next_target = next(self.loader)
        except StopIteration:
            self.next_input = None
            self.next_target = None
            return
        with torch.cuda.stream(self.stream):
            self.next_input = self.next_input.cuda(non_blocking=True).float()
            self.next_target = self.next_target.cuda(non_blocking=True).long()

    def next(self):
        torch.cuda.current_stream().wait_stream(self.stream)
        input = self.next_input
        target = self.next_target
        self.preload()
        return input,target

class data_prefetcher_two():
    def __init__(self, loader1, loader2):
        self.stream = torch.cuda.Stream()
        self.loader1 = iter(loader1)
        self.loader2 = iter(loader2)
        self.preload()

    def preload(self):
        try:
            tmp_input1, tmp_target1 = next(self.loader1)
            tmp_input2, tmp_target2 = next(self.loader2)
            self.next_input,self.next_target = torch.cat((tmp_input1, tmp_input2)), torch.cat((tmp_target1, tmp_target2))

        except StopIteration:
            self.next_input = None
            self.next_target = None
            return
        with torch.cuda.stream(self.stream):
            self.next_input = self.next_input.cuda(non_blocking=True).float()
            self.next_target = self.next_target.cuda(non_blocking=True).long()

    def next(self):
        torch.cuda.current_stream().wait_stream(self.stream)
        input = self.next_input
        target = self.next_target
        self.preload()
        return input,target

class data_prefetcher_two_2():
    def __init__(self, loader1, loader2):
        self.stream = torch.cuda.Stream()
        self.loader1 = [iter(loader1),iter(loader1),iter(loader1),iter(loader1)]
        self.loader2 = iter(loader2)
        self.preload()

    def preload(self):
        try:
            tmp_input1, tmp_mask1, tmp_target1 = next(self.loader1[0],['1','1','1'])
            if tmp_input1 == '1':
                tmp_input1, tmp_mask1, tmp_target1 = next(self.loader1[1], ['2', '2', '2'])
            if tmp_input1 == '2':
                tmp_input1, tmp_mask1, tmp_target1 = next(self.loader1[2], ['3', '3', '3'])
            if tmp_input1 == '3':
                tmp_input1, tmp_mask1, tmp_target1 = next(self.loader1[3], ['4', '4', '4'])

            tmp_input2, tmp_mask2, tmp_target2 = next(self.loader2)
            self.next_input, self.next_mask, self.next_target = torch.cat((tmp_input1, tmp_input2)), torch.cat(
                (tmp_mask1, tmp_mask2)), torch.cat((tmp_target1, tmp_target2))

        except StopIteration:
            self.next_input = None
            self.next_mask = None
            self.next_target = None
            return
        with torch.cuda.stream(self.stream):
            self.next_input = self.next_input.cuda(non_blocking=True).float()
            self.next_mask = self.next_mask.cuda(non_blocking=True).float()
            self.next_target = self.next_target.cuda(non_blocking=True).long()

    def next(self):
        torch.cuda.current_stream().wait_stream(self.stream)
        input = self.next_input
        mask = self.next_mask
        target = self.next_target
        self.preload()
        return input, mask, target

class clg_loss(nn.Module):
    def __init__(self):
        super(clg_loss, self).__init__()
        self.relu = torch.nn.ReLU()

    def forward(self, pred, truth):
        batch = pred.shape[0]
        pred = pred.view(batch, -1)  # 拉成一维计算loss,shape为[batch,full-linear]
        truth = truth.view(batch, -1).requires_grad_(False)
        # print(pred, truth) pred.shape[batch,full-linear]
        pred, truth = self.relu(pred), self.relu(truth)
        if pred.shape != truth.shape:
            raise Exception('pred shape:', pred.shape, 'truth.shape:', truth.shape)
        else:
            loss = F.binary_cross_entropy(pred, truth)
        return loss

class MyLoss(torch.nn.Module):
    def __init__(self):
        super(MyLoss, self).__init__()
        self.relu = torch.nn.ReLU()

    def forward(self,pred,truth):
        batch = pred.shape[0]
        pred = pred.view(batch,-1) #拉成一维计算loss,shape为[batch,full-linear]
        truth = truth.view(batch,-1)
        # print(pred,truth)
        pred,truth = self.relu(pred),self.relu(truth)
        total_loss_list = []
        if pred.shape != truth.shape:
            raise Exception('pred shape:',pred.shape,'truth.shape:',truth.shape)
        else: # pred.shape[batch,full-linear]
            for i in range(pred.shape[0]): # 计算每个batch的loss
                total_loss = 0
                # print('计算第',i,"个batch的loss")
                # print(pred.shape[1]) 50176
                for j in range(pred.shape[1]):
                    pred[i][j] = torch.where(pred[i][j] == 0,torch.full_like(pred[i][j],1e-6),pred[i][j])
                    # print("pred:", pred[i],"1-pred:",1-pred[i],"true:",truth[i])
                    # 第i,j个loss，如：第一个batch的第一个元素的loss
                    # print("第",i,"个batch的第",j,"个元素的loss",truth[i][j],pred[i][j])
                    loss = - truth[i][j] * torch.log(pred[i][j]) - (1-truth[i][j])*torch.log(abs(1-pred[i][j])) # 计算每一个像素loss
                    # print(loss)
                    if torch.isnan(loss):
                        raise Exception("loss val is nan or lnf")
                    total_loss += loss #第i个batch的所有loss
                print("第", i, "个batch的所有loss之和", total_loss)
                total_loss_list.append(total_loss/pred.shape[1])
            print(total_loss_list)
            A = torch.stack(total_loss_list) #将存有Tensor数据的List转换为Tensor.
        return torch.mean(A)

class GradCAM():
    '''
    Grad-cam: Visual explanations from deep networks via gradient-based localization
    Selvaraju R R, Cogswell M, Das A, et al.
    https://openaccess.thecvf.com/content_iccv_2017/html/Selvaraju_Grad-CAM_Visual_Explanations_ICCV_2017_paper.html
    '''

    def __init__(self, model, target_layers, use_cuda=True):
        super(GradCAM).__init__()
        self.use_cuda = use_cuda
        self.model = model
        self.target_layers = target_layers

        self.target_layers.register_forward_hook(self.forward_hook)
        self.target_layers.register_full_backward_hook(self.backward_hook)

        self.activations = []
        self.grads = []

    def forward_hook(self, module, input, output):
        self.activations.append(output[0])

    def backward_hook(self, module, grad_input, grad_output):
        self.grads.append(grad_output[0].detach())

    def calculate_cam(self, model_input):
        if self.use_cuda:
            device = torch.device('cuda')
            self.model.to(device)  # Module.to() is in-place method
            model_input = model_input.to(device)  # Tensor.to() is not a in-place method
        self.model.eval()

        # forward
        y_hat = self.model(model_input)
        max_class = np.argmax(y_hat.cpu().data.numpy(), axis=1)

        # backward
        self.model.zero_grad()
        y_c = y_hat[0, max_class]
        y_c.backward()

        # get activations and gradients
        activations = self.activations[0].cpu().data.numpy().squeeze()
        grads = self.grads[0].cpu().data.numpy().squeeze()

        # calculate weights
        weights = np.mean(grads.reshape(grads.shape[0], -1), axis=1)
        weights = weights.reshape(-1, 1, 1)
        cam = (weights * activations).sum(axis=0)
        cam = np.maximum(cam, 0)  # ReLU
        cam = cam / cam.max()
        return cam

    @staticmethod
    def show_cam_on_image(image, cam):
        # image: [H,W,C]
        h, w = image.shape[:2]

        cam = cv2.resize(cam, (h, w))
        cam = cam / cam.max()
        heatmap = cv2.applyColorMap((255 * cam).astype(np.uint8), cv2.COLORMAP_JET)  # [H,W,C]
        heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)

        image = image / image.max()
        heatmap = heatmap / heatmap.max()

        result = 0.4 * heatmap + 0.6 * image
        result = result / result.max()

        plt.figure()
        plt.imshow((result * 255).astype(np.uint8))
        plt.colorbar(shrink=0.8)
        plt.tight_layout()
        plt.show()

    @staticmethod
    def preprocess_image(img, mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]):
        preprocessing = Compose([
            ToTensor(),
            Normalize(mean=mean, std=std)
        ])
        return preprocessing(img.copy()).unsqueeze(0)

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

def Eval(model,lossfunc,dtloader):
    model.eval() #模型进入评估模式
    sum_cls_loss = 0
    y_true_all = None
    y_pred_all = None

    with torch.no_grad(): #模型不进行梯度更新时,对模型进行评估
        for (j,batch) in enumerate(dtloader):
            x,y_true = batch # 获取真实标签
            y_pred = model.forward(x.cuda()) # 等同于model(x),获得预测标签
            # mask_pred = torchvision.transforms.Resize(224)(mask_pred)

            cls_loss = lossfunc(y_pred,y_true.cuda()) #获得损失值
            # mask_loss = imgloss(mask_pred,mask_true.cuda())

            sum_cls_loss += cls_loss.detach()*len(x)
            # sum_mask_loss += mask_loss.detach()*len(x)

            y_pred = torch.nn.functional.softmax(
                y_pred.detach(), dim=1)[:, 1].flatten() #计算softmax缩放数据

            if y_true_all is None:
                y_true_all = y_true
                y_pred_all = y_pred
            else:
                y_true_all = torch.cat((y_true_all,y_true))
                y_pred_all = torch.cat((y_pred_all,y_pred))

    return sum_cls_loss/len(y_true_all),y_true_all.detach(),y_pred_all.detach()

def Eval2(model,lossfunc,dtloader):
    model.eval() #模型进入评估模式
    sum_cls_loss = 0
    sum_mask_loss = 0
    y_true_all = None
    y_pred_all = None

    with torch.no_grad(): #模型不进行梯度更新时,对模型进行评估
        for (j,batch) in enumerate(dtloader):
            x,mid,y_true = batch # 获取真实标签
            y_pred = model.forward(x.cuda()) # 等同于model(x),获得预测标签
            # mask_pred = torchvision.transforms.Resize(224)(mask_pred)

            cls_loss = lossfunc(y_pred,y_true.cuda()) #获得损失值

            sum_cls_loss += cls_loss.detach()*len(x)

            y_pred = torch.nn.functional.softmax(
                y_pred.detach(), dim=1)[:, 1].flatten() #计算softmax缩放数据

            if y_true_all is None:
                y_true_all = y_true
                y_pred_all = y_pred
            else:
                y_true_all = torch.cat((y_true_all,y_true))
                y_pred_all = torch.cat((y_pred_all,y_pred))

    return sum_cls_loss/len(y_true_all),y_true_all.detach(),y_pred_all.detach()

def Eval3(model,lossfunc1,lossfunc2,dtloader):
    model.eval()  # 模型进入评估模式
    lossfunc2.eval()
    sum_cls_loss = 0
    sum_scl_loss = 0
    y_true_all = None
    y_pred_all = None

    with torch.no_grad():  # 模型不进行梯度更新时,对模型进行评估
        for (j, batch) in enumerate(dtloader):
            x, mid, y_true = batch  # 获取真实标签
            feat,y_pred = model.forward(x.cuda(), mid.cuda())  # 等同于model(x),获得预测标签

            cls_loss = lossfunc1(y_pred, y_true.cuda())  # 获得损失值
            scl_loss = lossfunc2(feat,y_true.cuda())

            sum_cls_loss += cls_loss.detach() * len(x)
            sum_scl_loss += scl_loss.detach() * len(x)

            y_pred = torch.nn.functional.softmax(
                y_pred.detach(), dim=1)[:, 1].flatten()  # 计算softmax缩放数据
            if y_true_all is None:
                y_true_all = y_true
                y_pred_all = y_pred
            else:
                y_true_all = torch.cat((y_true_all, y_true))
                y_pred_all = torch.cat((y_pred_all, y_pred))

    return sum_cls_loss / len(y_true_all),sum_scl_loss / len(y_true_all), y_true_all.detach(), y_pred_all.detach()

def cal_fam(model,inputs): #热量范
    model.zero_grad() #得到训练好的模型，不让其继续学习
    inputs = inputs.detach().clone() #不计算inputs的梯度
    inputs.requires_grad_()
    output = model(inputs)
    print(output)
    target = output[:,1]-output[:,0]
    target.backward(torch.ones(target.shape)) #反向传播计算inputs.grad
    fam = torch.abs(inputs.grad)
    fam = torch.max(fam,dim=1,keepdim=True)[0]
    return fam

def cal_normfam(model,inputs):
    fam = cal_fam(model,inputs)
    _,x,y = fam[0].shape
    fam = torch.nn.functional.interpolate(fam, (int(y / 2), int(x / 2)), mode='bilinear', align_corners=False) #用线性插值进行下采样
    fam = torch.nn.functional.interpolate(fam, (y, x), mode='bilinear', align_corners=False) #再上采样？
    for i in range(len(fam)):
        fam[i] -= torch.min(fam[i])
        fam[i] /= torch.max(fam[i])
    return fam

