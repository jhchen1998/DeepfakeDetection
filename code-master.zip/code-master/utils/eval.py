import torch

def Eval(model, lossfunc, dtloader):
    # 在评估模式下，batchNorm层，dropout层等用于优化训练而添加的网络层会被关闭
    # 从而使得评估时不会发生偏移，网络中所有参数都一致。
    model.eval()  # 进入评估模式，等同于 self.train(False)
    sumloss = 0.
    y_true_all = None
    y_pred_all = None

    with torch.no_grad():  # 不进行梯度更新
        # enumerate()函数用于将一个可遍历的数据对象（如列表、元组或字符串）组合为一个索引序列，同时列出数据和数据下标.
        for (j, batch) in enumerate(dtloader):
            x, y_true = batch
            # model(X) # or model.forward(X)
            y_pred = model.forward(x.cuda())

            loss = lossfunc(y_pred, y_true.cuda())
            sumloss += loss.detach() * len(x)

            y_pred = torch.nn.functional.softmax(
                y_pred.detach(), dim=1)[:, 1].flatten()

            if y_true_all is None:
                y_true_all = y_true
                y_pred_all = y_pred
            else:
                y_true_all = torch.cat((y_true_all, y_true))
                y_pred_all = torch.cat((y_pred_all, y_pred))

    return sumloss / len(y_true_all), y_true_all.detach(), y_pred_all.detach()