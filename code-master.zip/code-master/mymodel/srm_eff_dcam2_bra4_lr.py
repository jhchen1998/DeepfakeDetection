import os
import time
import torch
import torchvision
import numpy as np
import torch.nn.functional as F
from torch.optim import AdamW
import torch.nn as nn
from utils.bra import BiLevelRoutingAttention
from Pretrainedmodels.efficientnet import EfficientNet


class SRMConv2d_Separate(nn.Module):

    def __init__(self, inc, outc, learnable=True):
        super(SRMConv2d_Separate, self).__init__()
        self.inc = inc
        self.truc = nn.Hardtanh(-3, 3)
        kernel = self._build_kernel(inc)  # (3,3,5,5)
        self.kernel = nn.Parameter(data=kernel, requires_grad=learnable)
        # self.hor_kernel = self._build_kernel().transpose(0,1,3,2)
        self.out_conv = nn.Sequential(
            nn.Conv2d(3 * inc, outc, 1, 1, 0, 1, 1, bias=False),
            nn.BatchNorm2d(outc),
            nn.ReLU(inplace=True)
        )

        for ly in self.out_conv.children():
            if isinstance(ly, nn.Conv2d):
                nn.init.kaiming_normal_(ly.weight, a=1)

    def forward(self, x):
        '''
        x: imgs (Batch, H, W, 3)
        '''
        out = F.conv2d(x, self.kernel, stride=1, padding=2, groups=self.inc)
        out = self.truc(out)
        out = self.out_conv(out)

        return out

    def _build_kernel(self, inc):
        # filter1: KB
        filter1 = [[0, 0, 0, 0, 0],
                   [0, -1, 2, -1, 0],
                   [0, 2, -4, 2, 0],
                   [0, -1, 2, -1, 0],
                   [0, 0, 0, 0, 0]]
        # filter2：KV
        filter2 = [[-1, 2, -2, 2, -1],
                   [2, -6, 8, -6, 2],
                   [-2, 8, -12, 8, -2],
                   [2, -6, 8, -6, 2],
                   [-1, 2, -2, 2, -1]]
        # # filter3：hor 2rd
        filter3 = [[0, 0, 0, 0, 0],
                   [0, 0, 0, 0, 0],
                   [0, 1, -2, 1, 0],
                   [0, 0, 0, 0, 0],
                   [0, 0, 0, 0, 0]]

        filter1 = np.asarray(filter1, dtype=float) / 4.
        filter2 = np.asarray(filter2, dtype=float) / 12.
        filter3 = np.asarray(filter3, dtype=float) / 2.
        # statck the filters
        filters = [[filter1],  # , filter1, filter1],
                   [filter2],  # , filter2, filter2],
                   [filter3]]  # , filter3, filter3]]  # (3,3,5,5)
        filters = np.array(filters)
        # filters = np.repeat(filters, inc, axis=1)
        filters = np.repeat(filters, inc, axis=0)
        filters = torch.FloatTensor(filters)  # (3,3,5,5)
        # print(filters.size())
        return filters


class DFFM(nn.Module):
    def __init__(self, in_planes):
        super(DFFM, self).__init__()
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.mlp1 = nn.Sequential(
            nn.Conv2d(1, 1, 1, 1, 0, bias=False),
            nn.ReLU(),
            nn.Conv2d(1, 1, 1, 1, 0, bias=False))

        self.mlp2 = nn.Sequential(
            nn.Conv2d(in_planes * 2, in_planes, 1, 1, 0, bias=False),
            nn.ReLU(),
            nn.BatchNorm2d(in_planes)
        )

        self.sigmoid = nn.Sigmoid()

    def forward(self, rgb, noise):
        y = torch.mean(noise, dim=1, keepdim=True)
        y = self.mlp1(y)
        y = self.sigmoid(y)
        noise = y*rgb

        mix = torch.cat((rgb, noise), dim=1)
        mix = self.mlp2(mix)
        mix_a = torch.mean(mix, dim=1, keepdim=True)
        mix_a = self.mlp1(mix_a)

        out = mix*mix_a + rgb
        return out


class ModelBlock(nn.Module):
    def __init__(self):
        super().__init__()
        self.eff_rgb = EfficientNet.from_pretrained('efficientnet-b4', num_classes=2)

        self.conv_down1 = nn.Conv2d(24, 24, 3, 2, 1)
        self.conv_down2 = nn.Conv2d(32, 32, 3, 2, 1)

        self.mlp = nn.Sequential(
            nn.Conv2d(32, 32, 1, 1, 0, bias=False),
            nn.ReLU(),
            nn.BatchNorm2d(32)
        )

        self.dffm1 = DFFM(24)
        self.dffm2 = DFFM(32)

        self.srm_conv1 = SRMConv2d_Separate(3, 24)
        self.srm_conv2 = SRMConv2d_Separate(24, 32)

        self.trans1 = BiLevelRoutingAttention(32, 4)
        self.trans2 = BiLevelRoutingAttention(32, 7)

        self.last_linear = nn.Linear(1792, 2)

    def classifier(self, x):
        x = F.adaptive_avg_pool2d(x, (1, 1))
        x = x.view(x.size(0), -1)
        out = self.last_linear(x)
        return out

    def forward(self, x):

        srm = self.srm_conv1(x)

        x = self.eff_rgb.extract_features_0(x)
        y = self.conv_down1(srm)

        x = self.dffm1(x, y)

        x = self.eff_rgb.extract_features_1(x)
        y = self.srm_conv2(y)
        y = self.conv_down2(y)

        x = self.dffm2(x, y)

        x_b = x.permute(0, 2, 3, 1)
        x_b1 = self.trans1(x_b)
        x_b2 = self.trans2(x_b)
        x_b1 = x_b1.permute(0, 3, 1, 2)
        x_b2 = x_b2.permute(0, 3, 1, 2)

        x_add = x_b1 + x_b2
        x_fuse = self.mlp(x_add)
        x = x_fuse + x

        x = self.eff_rgb.extract_features_2(x)

        x = self.eff_rgb.extract_features_3(x)

        x = self.eff_rgb.extract_features_4(x)

        res = self.classifier(x)

        return res

