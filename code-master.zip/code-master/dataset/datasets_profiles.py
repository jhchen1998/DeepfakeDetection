import torchvision
import os
import dataset.DataTools as dt

aug_train = torchvision.transforms.Compose([
    torchvision.transforms.Resize(256),          # 将输入图片resize成统一尺寸
    torchvision.transforms.RandomCrop(224),      # 随机裁剪
    # torchvision.transforms.RandomVerticalFlip(p=0.5), # 随机垂直翻转，选择一个概率
    torchvision.transforms.RandomHorizontalFlip(),      # 随机水平翻转，选择一个概率
    torchvision.transforms.ToTensor(),           # 将PIL Image或numpy.ndarray转换为tensor，并归一化到[0,1]之间
    torchvision.transforms.Normalize(            # 标准化处理-->转化为正态分布(高斯分布)，使模型更容易收敛
        [0.5, 0.5, 0.5], [0.25, 0.25, 0.25])     # (mean, std)
])                                               # 公式channel = (channel - mean) / std 进行规范化

aug_test = torchvision.transforms.Compose([
    torchvision.transforms.Resize(256),          # 将输入图片resize成统一尺寸
    torchvision.transforms.CenterCrop(224),      # 中心裁剪
    torchvision.transforms.ToTensor(),           # 将PIL Image或numpy.ndarray转换为tensor，并归一化到[0,1]之间
    torchvision.transforms.Normalize(            # 标准化处理-->转化为正态分布(高斯分布)，使模型更容易收敛
        [0.5, 0.5, 0.5], [0.25, 0.25, 0.25])
])

class selfdataset():
    def getDatasets(self, pathfunc, infolist, transform, process=None, datasetfunc=None):
        datalist = []
        for info in infolist:
            discribe = info[0]
            dirlist = info[1]
            label = info[2]
            cnt = 0
            for dirname in dirlist:
                path = pathfunc(self.folder_path, dirname)
                cnt += len(os.listdir(path))
                datalist.append((path, label))
            print(discribe, cnt)
        if datasetfunc is not None:
            dataset = datasetfunc(datalist, transform=transform, process=process)
        else:
            dataset = dt.imgdataset(datalist, transform=transform, process=process)
        return dataset

    # 获取数据路径？
    def getsetlist(self, real, setType, process=None, datasetfunc=None):
        setdir = self.R_dir if real is True else self.F_dir
        label = 0 if real is True else 1
        aug = aug_train if setType == 0 else aug_test
        pathfunc = self.trainpath if setType == 0 else self.validpath if setType == 1 else self.testpath
        setlist = []
        for setname in setdir:
            datalist = [(pathfunc(self.folder_path, setname), label)]
            if datasetfunc is not None:
                tmptestset = datasetfunc(datalist, transform=aug, process=process)
            else:
                tmptestset = dt.imgdataset(datalist, transform=aug, process=process)
            setlist.append(tmptestset)
        return setlist, setdir

    def getTrainsetR(self, process=None, datasetfunc=None):
        return self.getDatasets(self.trainpath, [[self.__class__.__name__+" TrainsetR", self.R_dir, 0]], aug_train, process=process, datasetfunc=datasetfunc)

    def getTrainsetF(self, process=None, datasetfunc=None):
        return self.getDatasets(self.trainpath, [[self.__class__.__name__+" TrainsetF", self.F_dir, 1]], aug_train, process=process, datasetfunc=datasetfunc)

    def getTrainset(self, process=None, datasetfunc=None):
        return self.getDatasets(self.trainpath, [[self.__class__.__name__+" TrainsetR", self.R_dir, 0], [self.__class__.__name__+" TrainsetF", self.F_dir, 1]], aug_train, process=process, datasetfunc=datasetfunc)

    def getValidsetR(self, process=None, datasetfunc=None):
        return self.getDatasets(self.validpath, [[self.__class__.__name__+" ValidsetR", self.R_dir, 0]], aug_test, process=process, datasetfunc=datasetfunc)

    def getValidsetF(self, process=None, datasetfunc=None):
        return self.getDatasets(self.validpath, [[self.__class__.__name__+" ValidsetF", self.F_dir, 1]], aug_test, process=process, datasetfunc=datasetfunc)

    def getValidset(self, process=None, datasetfunc=None):
        return self.getDatasets(self.validpath, [[self.__class__.__name__+" ValidsetR", self.R_dir, 0], [self.__class__.__name__+" ValidsetF", self.F_dir, 1]], aug_test, process=process, datasetfunc=datasetfunc)

    def getTestsetR(self, process=None, datasetfunc=None):
        return self.getDatasets(self.testpath, [[self.__class__.__name__+" TestsetR", self.R_dir, 0]], aug_test, process=process, datasetfunc=datasetfunc)

    def getTestsetF(self, process=None, datasetfunc=None):
        return self.getDatasets(self.testpath, [[self.__class__.__name__+" TestsetF", self.F_dir, 1]], aug_test, process=process, datasetfunc=datasetfunc)

    def getTestset(self, process=None, datasetfunc=None):
        return self.getDatasets(self.testpath, [[self.__class__.__name__+" TestsetR", self.R_dir, 0], [self.__class__.__name__+" TestsetF", self.F_dir, 1]], aug_test, process=process, datasetfunc=datasetfunc)


class DFDC(selfdataset):
    def __init__(self,folder_path="/data/DeepfakeDatasets/DFDC"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        # self.R_dir = ["ffhq","CelebAMask-HQ"]
        # self.F_dir = ["faceapp","pggan_v2","stargan","stylegan_celeba","stylegan_ffhq"]
        self.R_dir = ["real_new"]
        self.F_dir = ["fake_new"]
        # 下面三个为函数，加载进入父类的第一个参数
        self.trainpath = lambda path,file:os.path.join(self.folder_path,file)
        self.validpath = lambda path, file: os.path.join(self.folder_path, file)
        self.testpath = lambda path,file:os.path.join(self.folder_path,file)

class fsh_c23(selfdataset):
    def __init__(self,folder_path="/data/ChenJH/Faceshifter_new/"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["original"]
        self.F_dir = ["faceshifter"]
        # 下面三个为函数，加载进入父类的第一个参数
        self.trainpath = lambda path,file:os.path.join(self.folder_path,file,"c23","train")
        self.validpath = lambda path, file: os.path.join(self.folder_path, file,"c23","val")
        self.testpath = lambda path,file:os.path.join(self.folder_path,file,"c23","test")

class fsh_c40(selfdataset):
    def __init__(self,folder_path="/data/ChenJH/Faceshifter_new/"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["original"]
        self.F_dir = ["faceshifter"]
        # 下面三个为函数，加载进入父类的第一个参数
        self.trainpath = lambda path,file:os.path.join(self.folder_path,file,"c40","train")
        self.validpath = lambda path, file: os.path.join(self.folder_path, file,"c40","val")
        self.testpath = lambda path,file:os.path.join(self.folder_path,file,"c40","test")

class wildedeepfake(selfdataset):
    def __init__(self,folder_path="/data/ChenJH/wilddeepfake_scale/"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["real"]
        self.F_dir = ["fake"]
        # 下面三个为函数，加载进入父类的第一个参数
        self.trainpath = lambda path,file:os.path.join(self.folder_path,file,"train")
        # self.validpath = lambda path, file: os.path.join(self.folder_path, file, "val_face")
        self.testpath = lambda path,file:os.path.join(self.folder_path,file,"test")

class CelebDF(selfdataset):
    def __init__(self,folder_path="/data/DeepfakeDatasets/Celeb-DF-img"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["Real"]
        self.F_dir = ["Fake"]
        self.trainpath = lambda path,file: os.path.join(self.folder_path,file,"train","face")
        # self.validpath = lambda path,file: os.path.join(self.folder_path,file,"val","face")
        self.testpath = lambda path,file:os.path.join(self.folder_path,file,"test","face")

class FFc40old(selfdataset):
    def __init__(self,folder_path="/data/ChenJH/c40_video"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["original"]
        self.F_dir = ["deepfakes","face2face","faceswap","neuraltextures"]
        self.trainpath = lambda path,file:os.path.join(self.folder_path, file ,"train_face")
        self.validpath = lambda path, file: os.path.join(self.folder_path, file, "val_face")
        self.testpath  = lambda path,file:os.path.join(self.folder_path, file,"test_face")

class FFc40DF(selfdataset):
    def __init__(self,folder_path="/data/DeepfakeDatasets/FaceForensics++/c40_video"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["original"]
        self.F_dir = ["deepfakes"]
        self.trainpath = lambda path, file: os.path.join(self.folder_path,file,"train_face")
        self.validpath = lambda path, file: os.path.join(self.folder_path, file, "val_face")
        self.testpath  = lambda path, file: os.path.join(self.folder_path,file,"test_face")

class FFc40FF(selfdataset):
    def __init__(self, folder_path="/data/DeepfakeDatasets/FaceForensics++/c40_video"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["original"]
        self.F_dir = ["face2face"]
        self.trainpath = lambda path, file : os.path.join(self.folder_path, file, "train_face")
        self.validpath = lambda path, file: os.path.join(self.folder_path, file, "val_face")
        self.testpath  = lambda path, file : os.path.join(self.folder_path, file, "test_face")

class FFc40FS(selfdataset):
    def __init__(self, folder_path="/data/DeepfakeDatasets/FaceForensics++/c40_video"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["original"]
        self.F_dir = ["faceswap"]
        self.trainpath = lambda path, file : os.path.join(self.folder_path, file, "train_face")
        self.validpath = lambda path, file: os.path.join(self.folder_path, file, "val_face")
        self.testpath  = lambda path, file : os.path.join(self.folder_path, file, "test_face")

class FFc40NT(selfdataset):
    def __init__(self, folder_path="/data/DeepfakeDatasets/FaceForensics++/c40_video"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["original"]
        self.F_dir = ["neuraltextures"]
        self.trainpath = lambda path, file : os.path.join(self.folder_path, file, "train_face")
        self.validpath = lambda path, file: os.path.join(self.folder_path, file, "val_face")
        self.testpath  = lambda path, file : os.path.join(self.folder_path, file, "test_face")

class FFc40new(selfdataset):
    def __init__(self,folder_path="/data/DeepfakeDatasets/FaceForensics++/c40_video"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["original"]
        self.F_dir = ["deepfakes","face2face","faceswap","neuraltextures"]
        self.trainpath = lambda path,file:os.path.join(self.folder_path,file,"train_face")
        self.validpath = lambda path, file: os.path.join(self.folder_path, file, "val_face")
        self.testpath = lambda path,file:os.path.join(self.folder_path,file,"test_face")

class FFc23DF(selfdataset):
    def __init__(self,folder_path="/data/DeepfakeDatasets/FaceForensics++/c23_video"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["original"]
        self.F_dir = ["deepfakes"]
        self.trainpath = lambda path,file:os.path.join(self.folder_path,file,"train_face")
        self.validpath = lambda path, file: os.path.join(self.folder_path, file, "val_face")
        self.testpath = lambda path,file:os.path.join(self.folder_path,file,"test_face")

class FFc23FF(selfdataset):
    def __init__(self,folder_path="/data/DeepfakeDatasets/FaceForensics++/c23_video"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["original"]
        self.F_dir = ["face2face"]
        self.trainpath = lambda path,file:os.path.join(self.folder_path,file,"train_face")
        self.validpath = lambda path, file: os.path.join(self.folder_path, file, "val_face")
        self.testpath = lambda path,file:os.path.join(self.folder_path,file,"test_face")

class FFc23FS(selfdataset):
    def __init__(self,folder_path="/data/DeepfakeDatasets/FaceForensics++/c23_video"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["original"]
        self.F_dir = ["faceswap"]
        self.trainpath = lambda path,file:os.path.join(self.folder_path,file,"train_face")
        self.validpath = lambda path, file: os.path.join(self.folder_path, file, "val_face")
        self.testpath = lambda path,file:os.path.join(self.folder_path,file,"test_face")

class FFc23NT(selfdataset):
    def __init__(self,folder_path="/data/DeepfakeDatasets/FaceForensics++/c23_video"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["original"]
        self.F_dir = ["neuraltextures"]
        self.trainpath = lambda path,file:os.path.join(self.folder_path,file,"train_face")
        self.validpath = lambda path, file: os.path.join(self.folder_path, file, "val_face")
        self.testpath = lambda path,file:os.path.join(self.folder_path,file,"test_face")


class FFc23old(selfdataset):
    def __init__(self,folder_path="/data/ChenJH/c23_video"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["original"]
        self.F_dir = ["deepfakes","face2face","faceswap","neuraltextures"]
        self.trainpath = lambda path, file: os.path.join(self.folder_path, file, "train_face")
        self.validpath = lambda path, file: os.path.join(self.folder_path, file, "val_face")
        self.testpath = lambda path, file: os.path.join(self.folder_path, file, "test_face")

class srm(selfdataset):
    def __init__(self,folder_path="/data/DeepfakeDatasets/srm"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["original"]
        self.F_dir = ["ff"]
        self.trainpath = lambda path, file: os.path.join(self.folder_path, file)
        # self.validpath = lambda path, file: os.path.join(self.folder_path, file, "val_face")
        self.testpath = lambda path, file: os.path.join(self.folder_path, file)

class FFc23new(selfdataset):
    def __init__(self,folder_path="/data/DeepfakeDatasets/FaceForensics++/c23_video"):
        super(selfdataset,self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["original"]
        self.F_dir = ["deepfakes","face2face","faceswap","neuraltextures"]
        self.trainpath = lambda path, file: os.path.join(self.folder_path, file, "train_face")
        self.validpath = lambda path, file: os.path.join(self.folder_path, file, "val_face")
        self.testpath = lambda path, file: os.path.join(self.folder_path, file, "test_face")

class DFFD(selfdataset):
    def __init__(self, folder_path="../DFFD/"):
        super(selfdataset, self).__init__()
        self.folder_path = folder_path
        self.R_dir = ["FFHQ", "CelebaHQ"]
        self.F_dir = ["StyleGAN_FFHQ", "StyleGAN_Celeba", "FaceAPP", "PGGAN", "StarGAN"]
        self.trainpath = lambda path, file: os.path.join(self.folder_path, file, "train")
        self.validpath = lambda path, file: os.path.join(self.folder_path, file, "validation")
        self.testpath = lambda path, file: os.path.join(self.folder_path, file, "test")




