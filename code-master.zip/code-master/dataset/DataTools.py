""" Module for the data loading pipeline for the model to train """
from torchvision.datasets.vision import VisionDataset
# PIL: Python Image Library
from PIL import Image
import cv2
import numpy as np
import os
import random


class imgdataset(VisionDataset):    # 继承VisionDataset类
    # 参数分别代表数据的目录、数据训练过程(真、假训练)、数据预处理、数据是否随机丢弃
    def __init__(self, rootlist, process=None, transform=None, randomdrop=0):
        super(imgdataset, self).__init__(root="", transform=transform)
        self.rootlist = rootlist
        self.randomdrop = randomdrop
        self.dataset = []
        self.process = process
        for root, label in self.rootlist:   # 读取图像目录和标签
            # os.listdir() 方法用于返回指定的文件夹包含的文件或文件夹的名字的列表
            imglist = os.listdir(root)
            print("Loading %s" % (root), end="\r")
            for p in imglist:
                self.dataset.append((os.path.join(root, p), label))
            print("Loaded %s=>%d" % (root, len(imglist)))

    def shuffle(self):
        # random.shuffle(list) 用来打乱这个list的顺序
        random.shuffle(self.dataset)

    def reset(self):
        self.dataset = []
        for root, label in self.rootlist:
            # os.listdir() 方法用于返回指定的文件夹包含的文件或文件夹的名字的列表
            imglist = os.listdir(root)
            for p in imglist:
                self.dataset.append((os.path.join(root, p), label))

    def __getitem__(self, index):
        img, label = self.dataset[index]
        img = Image.open(img)   # 图片读取
        img = np.array(img)
        img = cv2.resize(img, (256, 256))   # 重新设定图片大小，默认使用双线性插值
        img = Image.fromarray(img)   # array转化为image
        if self.transform is not None:
            img = self.transform(img)
        return img, label

    def __len__(self):
        return len(self.dataset)

    def __add__(self, other):
        self.dataset.extend(other.dataset)
        return self
