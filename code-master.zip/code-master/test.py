import torch
import os
from dataset.util import calRes
from torch.utils.data import DataLoader
import dataset.datasets_profiles as dp
from utils.eval import Eval
from mymodel.srm_eff_dcam2_bra3_lr import ModelBlock
from train_eff import ModelEff
from Pretrainedmodels.resnet18_gram import resnet18
from Pretrainedmodels.mesonet import Meso4
from Pretrainedmodels.mesonet import MesoInception4

os.environ["CUDA_VISIBLE_DEVICES"] = '0, 1, 2, 3'
device_ids = [0,1,2,3]

if __name__ == '__main__':
    device = 'cuda:2'
    torch.cuda.set_device(device)

    model = ModelBlock().cuda()
    # model = resnet18().cuda()
    # model = Meso4().cuda()

    # pre_d = torch.load('/data/ChenJH/myieee/models_gai/xbase_c40DF_srm_eff_dcam2_bra3_lr_model_batch_85756', map_location=device)  # DF: ACC:50.962343 AUC:0.621675 FF; ACC:51.610879 AUC:0.641010 FS; ACC:50.983264 AUC:0.618367 NT;
    pre_d = torch.load('/data/ChenJH/myieee/models_gai/xbase_c40FF_srm_eff_dcam2_bra3_lr_model_batch_46776', map_location=device)    # FF: ACC:50.962343 AUC:0.621675 FF; ACC:51.610879 AUC:0.641010 FS; ACC:50.983264 AUC:0.618367 NT;


    # pre_d = torch.load('/home/csust/ChenJH/my2023/models/xbase_c23new_meso4_model_batch_15668', map_location=device)                       # wild:ACC:64.431159 AUC:0.685166  DFDC:ACC:88.147678 AUC:0.493131   celeb:ACC:48.249360 AUC:0.583176
    # pre_d = torch.load('/home/csust/ChenJH/my2023/models_snd/xbase_c23new_srm_eff_dcam2_bra_lr_model_batch_125344',map_location=device)    # ACC:68.225405 AUC:0.733846  wild     # ACC:42.928191 AUC:0.682511  dfdc
    # pre_d = torch.load('/home/csust/ChenJH/my2023/models_snd/xbase_c23new_srm_eff_dcam2_bra_lr_model_batch_172348',map_location=device)    # ACC:27.584369 AUC:0.674648  dfdc     # ACC:64.010891 AUC:0.716465  wild


    model.load_state_dict(pre_d)
    model.eval()
    lossfunc = torch.nn.CrossEntropyLoss()

    dataset = dp.FFc40DF()

    # dataset = dp.wildedeepfake()
    # dataset = dp.DFDC()
    # dataset = dp.CelebDF()
    
    testsetR = dataset.getTestsetR()
    TestsetList, TestsetName = dataset.getsetlist(real=False, setType=2)

    testdataloaderR = DataLoader(
        testsetR,
        batch_size=32,
        num_workers=8
    )
    testdataloaderList = []
    for tmptestset in TestsetList:
        testdataloaderList.append(
            DataLoader(
                tmptestset,
                batch_size=32,
                num_workers=8
            )
        )

    loss_r, y_true_r, y_pred_r = Eval(model, lossfunc, testdataloaderR)

    sumACC = sumAUC = sumTPR_2 = sumTPR_3 = sumTPR_4 = 0
    for i, tmptestdataloader in enumerate(testdataloaderList):
        loss_f, y_true_f, y_pred_f = Eval(model, lossfunc, tmptestdataloader)
        ap, acc, AUC, TPR_2, TPR_3, TPR_4 = calRes(torch.cat((y_true_r, y_true_f)),
                                                   torch.cat((y_pred_r, y_pred_f)))
        sumACC += acc
        sumAUC += AUC
        sumTPR_2 += TPR_2
        sumTPR_3 += TPR_3
        sumTPR_4 += TPR_4
        print("ACC:%.6f AUC:%.6f TPR_2:%.6f TPR_3:%.6f TPR_4:%.6f %s" % (acc, AUC, TPR_2, TPR_3, TPR_4, TestsetName[i]))

    if len(testdataloaderList) > 1:
        print("ACC:%.6f AUC:%.6f TPR_2:%.6f TPR_3:%.6f TPR_4:%.6f Test" %
            (sumACC / len(testdataloaderList) ,sumAUC / len(testdataloaderList), 
             sumTPR_2 / len(testdataloaderList),sumTPR_3 / len(testdataloaderList), 
             sumTPR_4 / len(testdataloaderList)))
